                       The Global Airport Database
                         Release Version 0.0.2

Author: Arash Partow

Copyright notice:
Free use of the Global Airport Database is permitted under the
guidelines and in accordance with the most current version of
the MIT License.
http://www.opensource.org/licenses/MIT


[INTRODUCTION]
The Global Airport Database (GADB) is a FREE downloadable database  of
9300 airports big and small from all around the world. The database is
presented in a simple token delimited format.


For more information please visit:

http://www.partow.net/miscellaneous/airportdatabase/index.html
